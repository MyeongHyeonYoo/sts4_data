package com.cos.blog.test;

public class People {
	private int hungryState = 50;
	
	public void eat() {
		hungryState += 10;
	}
	
}
