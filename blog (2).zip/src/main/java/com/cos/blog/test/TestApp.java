package com.cos.blog.test;

public class TestApp {
	public static void main(String[] args) {
		People 홍길동 = new People();
		홍길동.eat();
	}
}
